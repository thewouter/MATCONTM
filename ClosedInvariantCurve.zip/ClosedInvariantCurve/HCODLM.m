%Hard Coded Output initial point Delayed Logistic Map
function X = HCODLM(epsilon)
% [a01 a02 a11 a12 b11 b12]
X = [0.5 0.5 epsilon 2*epsilon sqrt(3)*epsilon 0]';
end