function out = fixedpointmap
%
% Fixed Point of  Map curve definition file for a problem in mapfile
% 

global cds fpmds
    out{1}  = @curve_func;
    out{2}  = @defaultprocessor;
    out{3}  = @options;
    out{4}  = @jacobian;
    out{5}  = @hessians;
    out{6}  = @testf;
    out{7}  = @userf;
    out{8}  = @process;
    out{9}  = @singmat;
    out{10} = @locate;
    out{11} = @init;
    out{12} = @done;
    out{13} = @adapt;
return
%-------------------------------------------------------
function func = curve_func(arg)
NN=(length(FC)/3-1)/2;
theta=2*pi*(0:2*NN)/(2*NN+1); %create list of theta_0, ..., theta_{2N} with step size 1/(2N+1)
ind=[1:6,8:length(FC)]; %Keep first component of sine fixed to zero
eps=1e-4;
func=zeros(3,length(theta));
func_handles = feval(@AdaptiveControlMap);map=func_handles{2};


%Evaluate the map DD=F(x(t))-x(t+rho)
for ii=1:length(theta)
  func(:,ii)=feval(map,0,FCMAP(theta(ii),FC),ps{:})-FCMAP(theta(ii)+rho,FC);
end
%---------------------------------------------------------------
function jac = jacobian(varargin)
   jac=zeros(length(FC));
parfor kk=1:length(FC)-1
  jj=ind(kk);
  d1=nan(size(func));
  d2=nan(size(func));
  F1=FC;F1(jj)=F1(jj)+eps;
  F2=FC;F2(jj)=F2(jj)-eps;
  for ii=1:length(theta)
    d1(:,ii)=feval(map,0,FCMAP(theta(ii),F1),ps{:})-FCMAP(theta(ii)+rho,F1);
    d2(:,ii)=feval(map,0,FCMAP(theta(ii),F2),ps{:})-FCMAP(theta(ii)+rho,F2);
  end
  jac(:,kk)=(reshape(d1,length(FC),1)-reshape(d2,length(FC),1))/(2*eps);
end
%wrt System Parameter
ps1=ps;ps2=ps;ps1{1}=ps1{1}+eps;ps2{1}=ps2{1}-eps;
for ii=1:length(theta)
  d1(:,ii)=feval(map,0,FCMAP(theta(ii),FC),ps1{:})-FCMAP(theta(ii)+rho,FC);
  d2(:,ii)=feval(map,0,FCMAP(theta(ii),FC),ps2{:})-FCMAP(theta(ii)+rho,FC);
end
jac(:,end)=(reshape(d1,length(FC),1)-reshape(d2,length(FC),1))/(2*eps);

end
   %---------------------------------------------------------------    
function hess = hessians(varargin)  
hess =[]; 
%---------------------------------------------------------------
function varargout = defaultprocessor(varargin)
%-------------------------------------------------------------
function option = options
  %----------------------------------------------------------------
function [out, failed] = testf(id, x, v) 
%-----------------------------------------------------------------
function [out, failed] = userf(userinf, id, x, v)
%---------------------------------------------------------------------
function [failed,s] = process(id, x, v, s)

%------------------------------------------------------------
function [S,L] = singmat
% 0: testfunction must vanish
% 1: testfunction must not vanish
% everything else: ignore this testfunction

  S = [];

  L = [];

%--------------------------------------------------------
function [x,v] = locate(id, x1, v1, x2, v2)
%---------------------------------------------------------
function varargout = init(varargin)
%---------------------------------------------------------
function varargout = done

%----------------------------------------------------------  
function [res,x,v] = adapt(x,v)
res = []; % no re-evaluations needed

  


%----------------------------------------------------------------
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% ---------------------------------------------------------------

function [x,p] = rearr(x0)


% ---------------------------------------------------------------
function [x,v] = locateBP(id, x1, v1, x2, v2)


% ---------------------------------------------------------------

function [A, f] = locjac(x, b, p)
% A = mjac of system
% f = system evaluated at (x,b,p)


% ---------------------------------------------------------

function WorkspaceInit(x,v)


% ------------------------------------------------------
function WorkspaceDone

% -------------------------------------------------------


%SD:continues equilibrium of mapfile